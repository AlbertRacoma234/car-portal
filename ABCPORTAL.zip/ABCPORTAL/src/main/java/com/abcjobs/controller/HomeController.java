package com.abcjobs.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class HomeController {
		@RequestMapping(value="/") // home page
		public ModelAndView index() {
			return new ModelAndView("/home");
		}
		
		@RequestMapping(value="/home") // home page
		public ModelAndView home() {
			return new ModelAndView("/home");
		}
		@RequestMapping(value="/dashboard") // dashboard page
		public ModelAndView dashboard() {
			return new ModelAndView("/dashboard");
		}
		
		
	
		@RequestMapping(value="/verified")
		public ModelAndView verified(HttpServletResponse res) throws Exception {
			return new ModelAndView("verified"); 
		}
		
		
}
	
