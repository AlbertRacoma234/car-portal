package helper;

import java.util.List;

import com.abcjobs.model.Educations;
import com.abcjobs.model.Experiences;

public class Profile {
	private Long id;
	private String firstName;
	private String lastName;
	private String fullName;
	private String title;
	private String about;
	private String gender;
	private String province;
	private String country;
	private String company;



	
	private List<Experiences> ex;
	private List<Educations> ed;
	public Profile(Long id, String firstName, String lastName, String fullName, String title, String about,String gender,String province,
			String country,String company,List<Experiences> ex, List<Educations> ed) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.fullName = fullName;
		this.title = title;
		this.about = about;
		this.gender = gender;
		this.province = province;
		this.country = country;
	
		this.company = company;
	
		this.ex = ex;
		this.ed = ed;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	public List<Experiences> getEx() {
		return ex;
	}
	public void setEx(List<Experiences> ex) {
		this.ex = ex;
	}
	public List<Educations> getEd() {
		return ed;
	}
	public void setEd(List<Educations> ed) {
		this.ed = ed;
	}
	
	
}
